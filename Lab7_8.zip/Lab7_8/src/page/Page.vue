<template>
    <h1 style="text-align: center;">Page</h1><br>
    <p style="text-align: center;">ahdngfsjdgsbgdbgdbdbdgf</p>
</template>