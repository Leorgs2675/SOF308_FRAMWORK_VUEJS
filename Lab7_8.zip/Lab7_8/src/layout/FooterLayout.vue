<template>
    <h1 style="text-align: center;">Footer</h1>
</template>