<template>
    <h1 style="text-align: center;">Header</h1>
    <RouterLink to="/">Dong Ho</RouterLink>
    <RouterLink to="/page">Page</RouterLink>
</template>
