<template>
    <div>
      <h1>Trang Chủ</h1>
      <p>hi hi hi hi hi hi !</p>
    </div>
  </template>
  
  <script>
  export default {
    name: 'HomePage',
  };
  </script>
  