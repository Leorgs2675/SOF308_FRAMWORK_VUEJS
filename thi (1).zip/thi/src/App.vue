<template>
  <div id="app">
    <!-- Menu Bar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
      <div class="container-fluid">
        <a class="navbar-brand" href="#">Ứng Dụng</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav">
            <li class="nav-item">
              <router-link class="nav-link active" to="/">Trang Chủ</router-link>
            </li>
            <li class="nav-item">
              <router-link class="nav-link" to="/phones">Danh Sách Điện Thoại</router-link>
            </li>
          </ul>
        </div>
      </div>
    </nav>

  
    <router-view></router-view> 
  </div>
</template>

<script>
export default {
  name: 'App',
};
</script>

<style>

</style>
