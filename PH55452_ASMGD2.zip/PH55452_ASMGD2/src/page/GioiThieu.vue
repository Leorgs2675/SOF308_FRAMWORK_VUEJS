<template>
<div id="PageContainer" class="container">
    <main class="main-content" role="main">
        <section id="blog-wrapper">
            <div class="wrapper">
                <div class="inner">
                    <div class="row">

                        <article class="col-lg-9 col-md-12 col-sm-12 float-right grid__item large--nine-twelfths medium--one-whole small--one-whole" itemscope itemtype="http://schema.org/Article">

                            <div class="article-content">
                                <div class="article-head">
                                    <h1 class="mb-4">Giới thiệu Nhà xuất bản Kim Đồng</h1>
                                    <div class="row">
                                        <div class="col-6">
                                            <div class="article-date-comment">
                                                <div class="date"><i class="fa fa-calendar" aria-hidden="true"></i> 23/11/2024</div>
                                                <div class="comment"><i class="fa fa-commenting-o" aria-hidden="true"></i> <span class="fb-comments-count" data-href="https://nxbkimdong.com.vn/blogs/gioi-thieu/gioi-thieu-nha-xuat-ban-kim-dong"></span></div>
                                                <div class="author">
                                                    <i class="fa fa-user" aria-hidden="true"></i> Leorgs
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-6 text-right">
                                            <div class="social-network-actions">
                                                <button class="btn btn-primary">Like</button>
                                                <button class="btn btn-secondary">Share</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="article-tldr clearfix"></div>

                                <div class="article-body">
                                    <div class="field-items">
                                        <div class="field-item even">
                                            <p>
                                                Nhà xuất bản Kim Đồng trực thuộc Trung ương Đoàn TNCS Hồ Chí Minh là Nhà xuất bản tổng hợp có chức năng xuất bản sách và văn hóa phẩm phục vụ thiếu nhi và các bậc phụ huynh trong cả nước, quảng bá và giới thiệu văn hóa Việt Nam ra thế giới.<br>
                                                Nhà xuất bản có nhiệm vụ tổ chức bản thảo, biên soạn, biên dịch, xuất bản và phát hành các xuất bản phẩm có nội dung: giáo dục truyền thống dân tộc, giáo dục về tri thức, kiến thức… trên các lĩnh vực văn học, nghệ thuật, khoa học kỹ thuật nhằm cung cấp cho các em thiếu nhi cũng như các bậc phụ huynh các kiến thức cần thiết trong cuộc sống, những tinh hoa của tri thức nhân loại nhằm góp phần giáo dục và hình thành nhân cách thế hệ trẻ.<br>
                                                Đối tượng phục vụ của Nhà xuất bản là các em từ tuổi nhà trẻ mẫu giáo (1 đến 5 tuổi), nhi đồng (6 đến 9 tuổi), thiếu niên (10 đến 15 tuổi) đến các em tuổi mới lớn (16 đến 18 tuổi) và các bậc phụ huynh.
                                            </p>

                                            <p><strong>THÔNG TIN CHUNG</strong><br>
                                                Tên giao dịch: Nhà xuất bản Kim Đồng<br>
                                                Tên giao dịch quốc tế: Kim Dong Publishing House<br>
                                                Ngày thành lập: 17 tháng 6 năm 1957<br>
                                                Cơ quan chủ quản: Trung ương Đoàn TNCS Hồ Chí Minh
                                            </p>

                                            <p><u><strong>Trụ sở chính:</strong></u><br>
                                                Địa chỉ: 55 Quang Trung, Hà Nội, Việt Nam<br>
                                                Điện thoại: (024) 39434730 – (024)3 9428653<br>
                                                Fax: (024) 38229085<br>
                                                Email: <a href="mailto:info@nxbkimdong.com.vn">info@nxbkimdong.com.vn</a><br>
                                                Website: <a href="http://www.nxbkimdong.com.vn/">www.nxbkimdong.com.vn</a>
                                            </p>

                                            <p><u><strong>Chi nhánh tại TP. Hồ Chí Minh</strong></u><br>
                                                Địa chỉ: 248 Cống Quỳnh, P. Phạm Ngũ Lão, Q.1, TP. Hồ Chí Minh<br>
                                                Điện thoại: (028) 39303832 – (028) 39303447<br>
                                                Fax: (028) 39305867<br>
                                                Email:<a href="mailto:cnkimdong@nxbkimdong.com.vn">cnkimdong@nxbkimdong.com.vn</a>
                                            </p>

                                            <p><u><strong>Chi nhánh tại Miền Trung</strong></u><br>
                                                Địa chỉ: 102 Ông Ích Khiêm, TP Đà Nẵng, Việt Nam<br>
                                                Điện thoại: (0511) 3812333 – (0511) 3812335<br>
                                                Fax: (0511) 3812334<br>
                                                Email: <a href="mailto:cnkimdongmt@nxbkimdong.com.vn">cnkimdongmt@nxbkimdong.com.vn</a><br>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="social-network-actions-outside text-right">
                                <div class="fb-send" data-href="https://nxbkimdong.com.vn/blogs/gioi-thieu/gioi-thieu-nha-xuat-ban-kim-dong"></div>
                                <div class="fb-like" data-href="https://nxbkimdong.com.vn/blogs/gioi-thieu/gioi-thieu-nha-xuat-ban-kim-dong" data-layout="button" data-action="like" data-size="small" data-show-faces="true" data-share="true"></div>
                            </div>
                        </article>

                        <div class="col-lg-3 col-md-12 col-sm-12">
                            <div class="blog-sidebar">
                                <div class="list-categories">
                                    <h3 class="blog-sb-title">Danh mục tin tức</h3>
                                    <ul class="list-unstyled">
                                        <li><a href="/blogs/hoat-dong">Hoạt động</a></li>
                                        <li><a href="/blogs/su-kien">Sự kiện</a></li>
                                        <li><a href="/blogs/diem-sach">Điểm sách</a></li>
                                        <li><a href="/blogs/sach-gia-sach-lau">Sách giả - Sách lậu</a></li>
                                        <li><a href="/blogs/lich-phat-hanh-sach-dinh-ky">Lịch phát hành sách định kỳ</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </section>
    </main>
</div>
</template>
<style>
/* CSS Custom */
#PageContainer {
    background-color: #f8f9fa;
    padding: 30px;
    margin-top: 20px;
}
.article-head h1 {
    font-size: 2.5rem;
    font-weight: bold;
    color: #343a40;
}
.list-categories ul li a {
    color: #007bff;
    text-decoration: none;
}
.list-categories ul li a:hover {
    text-decoration: underline;
}
</style>
