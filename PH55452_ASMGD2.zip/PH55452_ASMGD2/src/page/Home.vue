<template>
<header>
<div id="carouselExampleSlidesOnly" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="https://theme.hstatic.net/200000343865/1001052087/14/ms_banner_img3.jpg?v=1532" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="https://theme.hstatic.net/200000343865/1001052087/14/ms_banner_img4.jpg?v=1532" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="https://theme.hstatic.net/200000343865/1001052087/14/ms_banner_img2.jpg?v=1532" class="d-block w-100" alt="...">
    </div>
  </div>
</div>
</header>
<main>
    <div class="container">
        <h3>Sách Mới</h3>
        <div class="row">
            <div class="col-3">
                <div class="card" style="width: 18rem;">
  <img src="https://product.hstatic.net/200000343865/product/sieu-nhan-cua_bia_d91e564b3b5d46a6a20197355ae571de_large.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Siêu nhân cua</h5>
    <p>Siêu nhân Cua.</p>
    <p class="card-text">54,000₫</p>
  </div>
</div>
            </div>
            <div class="col-3">
                <div class="card" style="width: 18rem;">
  <img src="https://product.hstatic.net/200000343865/product/ngai-ho_-betsy-va-con-ngua-bien-vang_bia_fa7bd11ec6994a23b55a25c813460e75_large.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Ngài Hổ, Betsy và con ngựa biển vàng</h5>
    <p class="card-text">45,000₫</p>
  </div>
</div>
            </div>
            <div class="col-3">
                <div class="card" style="width: 18rem;">
  <img src="https://product.hstatic.net/200000343865/product/ngai-ho_-betsy-va-chu-rong-bien_bia_b80b4a28e0d540e5996d6dfa7c79a403_large.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Ngài Hổ, Betsy và chú Rồng Biển</h5>
    <p class="card-text">45,000₫</p>
    
  </div>
</div>
            </div>
            <div class="col-3">
                <div class="card" style="width: 18rem;">
  <img src="https://product.hstatic.net/200000343865/product/ngai-ho_-betsy-va-mat-trang-xanh_bia_9b5202053e2f4a85b5bd163a667277a2_large.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Ngài Hổ, Betsy và Mặt Trăng Xanh</h5>
    <p class="card-text">45,000₫</p>
    
  </div>
</div>
            </div>
        </div>
        <h3>SÁCH BÁN CHẠY</h3>
        <div class="row">
            <div class="col-3">
                <div class="card" style="width: 18rem;">
  <img src="https://product.hstatic.net/200000343865/product/bup-sen-xanh---tb-2022_a6e962d1ceec452d8efaed8162fa0928_e40c26cb340a439185360675cff58ffa_large.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Búp sen xanh</h5>
    <p class="card-text">100,800₫</p>
  </div>
</div>
            </div>
            <div class="col-3">
                <div class="card" style="width: 18rem;">
  <img src="https://product.hstatic.net/200000343865/product/103_8b03a2f691474a01bea7c3b7b7010519_large.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Thám tử lừng danh Conan - Tập 103</h5>
    <p class="card-text">45,000₫</p>
  </div>
</div>
            </div>
            <div class="col-3">
                <div class="card" style="width: 18rem;">
  <img src="https://product.hstatic.net/200000343865/product/an-tao-101-dieu-can-biet-ve-tuong-lai_bff86af1fe2f40f9bde4dad06b29721f_67d4228fb4ad4e038a7c00c42493dfc7_large.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">AI - Trí tuệ nhân tạo - 101 điều cần biết ...</h5>
    <p class="card-text">100,800₫</p>
    
  </div>
</div>
            </div>
            <div class="col-3">
                <div class="card" style="width: 18rem;">
  <img src="https://product.hstatic.net/200000343865/product/14_248125031fc641f1b8567c313fdaa3c2_large.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Tý Quậy - Tập 14</h5>
    <p>Tý Quậy - Tập 14.</p>
    <p>truyện tranh Việt Nam</p>
    <p class="card-text">45,000₫</p>
    
  </div>
</div>
            </div>
        </div>
    </div>
    <img src="https://theme.hstatic.net/200000343865/1001052087/14/banner_home_pro_5.jpg?v=1532" width="100%" alt="">
    <div class="container">
         <div class="row">
            <div class="col-3">
                <div class="card" style="width: 18rem;">
  <img src="https://product.hstatic.net/200000343865/product/doraemon-movie-story-mau_tan-nobita-va-nuoc-nhat-thoi-nguyen-thuy_bia_fe90384047734857b6955a8c97b65d06_large.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Doraemon Movie Story màu - Tân Nobita và n...</h5>
    <p class="card-text">100,800₫</p>
  </div>
</div>
            </div>
            <div class="col-3">
                <div class="card" style="width: 18rem;">
  <img src="https://product.hstatic.net/200000343865/product/8_f2781239f8a2419da6ad32911ec6d4f1_bfc9799e43dd4caaa7ef4ead6fb54d55_large.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Doraemon - Tuyển tập theo chủ đề - Tập 8 -...</h5>
    <p class="card-text">45,000₫</p>
  </div>
</div>
            </div>
            <div class="col-3">
                <div class="card" style="width: 18rem;">
  <img src="https://product.hstatic.net/200000343865/product/7_3433f7c9c91641868288ceabd96f630b_8e20b83d7c3a4e388cbcb4d90a2e33cc_large.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Doraemon - Tuyển tập theo chủ đề - Tập 7 -...</h5>
    <p class="card-text">100,800₫</p>
    
  </div>
</div>
            </div>
            <div class="col-3">
                <div class="card" style="width: 18rem;">
  <img src="https://product.hstatic.net/200000343865/product/4_a6908266d5c043169160e93be5b7813b_56d893600f4b4d3b8ed7990e01c0d9af_large.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Doraemon - Tuyển tập theo chủ đề - Tập 4 -...</h5>
    <p class="card-text">45,000₫</p>
    
  </div>
</div>
            </div>
        </div>
    </div>
</main>
</template>
<style>
    .container h3  {
        text-align: center;
        margin-bottom: 50px;
        margin-top: 40px;
    }
    img{
        margin-top: 30px;
        margin-bottom: 30px;
    }
</style>
