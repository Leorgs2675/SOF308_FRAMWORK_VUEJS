<template>
    <nav class="nav">
  <a class="nav-link active" aria-current="page"><RouterLink to="/"> Trang Chủ</RouterLink></a>
  <a class="nav-link"><RouterLink to="/gioi-thieu"> Giới Thiệu</RouterLink></a>
  <a class="nav-link"><RouterLink to="/tin-tuc">Tin Tức</RouterLink></a>
  <a class="nav-link"><RouterLink to="/lien-he">Liên Hệ</RouterLink></a>
  <a class="nav-link"><RouterLink to="/san-pham">Sản Phẩm</RouterLink></a>
  <a class="nav-link"><RouterLink to="/the-loai">Thể Loại Sản Phẩm</RouterLink></a>
  <a class="nav-link"><RouterLink to="/nhan-vien">Nhân Viên</RouterLink></a>
</nav>
</template>
